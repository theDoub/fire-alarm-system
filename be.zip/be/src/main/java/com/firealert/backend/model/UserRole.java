package com.firealert.backend.model;

/**
 * User Role Enum - Defines available roles in the system
 */
public enum UserRole {
    ADMIN("ROLE_ADMIN", "Administrator with full system access"),
    USER("ROLE_USER", "Regular user with standard permissions"),
    VIEWER("ROLE_VIEWER", "Read-only access to monitoring data");

    private final String authority;
    private final String description;

    UserRole(String authority, String description) {
        this.authority = authority;
        this.description = description;
    }

    public String getAuthority() {
        return authority;
    }

    public String getDescription() {
        return description;
    }
}
